import { createContext } from "react";
const Global = createContext();
export default Global;
